delete from user;
insert into user(id, name) values(1,'Rahul');
insert into user(id, name) values(2,'Rajesh');
insert into user(id, name) values(3,'Ramesh');