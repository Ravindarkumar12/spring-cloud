package edu.aspire.tx.programmatic;
public interface ITransferMoney {
	public void transfer(final int fromAccNo, final int toAccNo);
}
